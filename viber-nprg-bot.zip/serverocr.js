const express = require('express');
const ViberBot = require('viber-bot').Bot;
const BotEvents = require('viber-bot').Events;
const TextMessage = require('viber-bot').Message.Text;
const PictureMessage = require('viber-bot').Message.Picture;
const mongoose = require('mongoose');
const axios = require('axios');
const multer = require('multer');
const Tesseract = require('tesseract.js');
const sharp = require('sharp');
const fs = require('fs').promises;
const path = require('path');
require('dotenv').config();

const app = express();
app.use(express.json());

// Налаштування multer для завантаження файлів
const upload = multer({ 
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB
  }
});

// Створення папки для завантажених файлів
const uploadsDir = path.join(__dirname, 'uploads');
fs.mkdir(uploadsDir, { recursive: true }).catch(console.error);

// Підключення до MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/viber_nova_poshta', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Схема для відправок
const shipmentSchema = new mongoose.Schema({
  trackingNumber: {
    type: String,
    required: true,
    unique: true
  },
  senderCity: {
    type: String,
    required: true
  },
  recipientCity: {
    type: String,
    required: true
  },
  status: String,
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  viberUserId: String,
  senderAddress: String,
  recipientAddress: String,
  weight: Number,
  cost: Number
});

const Shipment = mongoose.model('Shipment', shipmentSchema);

// Схема для користувачів Viber
const userSchema = new mongoose.Schema({
  viberUserId: {
    type: String,
    required: true,
    unique: true
  },
  name: String,
  avatar: String,
  language: String,
  country: String,
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const User = mongoose.model('User', userSchema);

// Створення Viber бота
const bot = new ViberBot({
  authToken: process.env.VIBER_AUTH_TOKEN,
  name: "Nova Poshta Tracker",
  avatar: "https://example.com/avatar.jpg" // замініть на реальний URL
});

// API конфігурація Нової Пошти
const NOVA_POSHTA_API_KEY = process.env.NOVA_POSHTA_API_KEY;
const NOVA_POSHTA_API_URL = process.env.NOVA_POSHTA_API_URL; //'https://api.novaposhta.ua/v2.0/json/';

// Функція для отримання інформації про відправку з API Нової Пошти
async function getShipmentInfo(trackingNumber) {
  try {
    const response = await axios.post(NOVA_POSHTA_API_URL, {
      apiKey: NOVA_POSHTA_API_KEY,
      modelName: "TrackingDocument",
      calledMethod: "getStatusDocuments",
      methodProperties: {
        Documents: [
          {
            DocumentNumber: trackingNumber,
            Phone: ""
          }
        ]
      }
    });

    if (response.data.success && response.data.data.length > 0) {
      return response.data.data[0];
    }
    return null;
  } catch (error) {
    console.error('Помилка при отриманні даних з API Нової Пошти:', error);
    return null;
  }
}

// Функція для обробки зображення та витягування номера накладної
async function extractTrackingNumberFromImage(imagePath) {
  try {
    // Попередня обробка зображення для кращого розпізнавання
    const processedImagePath = imagePath + '_processed.jpg';
    
    await sharp(imagePath)
      .resize(1200, null, { 
        withoutEnlargement: true,
        fit: 'inside'
      })
      .greyscale()
      .normalize()
      .sharpen()
      .jpeg({ quality: 95 })
      .toFile(processedImagePath);

    // OCR розпізнавання
    const { data: { text } } = await Tesseract.recognize(processedImagePath, 'ukr+rus+eng', {
      logger: m => console.log('OCR Progress:', m)
    });
    
    console.log('Розпізнаний текст:', text);
    
    // Пошук номерів накладних у тексті (різні формати)
    const trackingPatterns = [
      /\b\d{14}\b/g,  // 14 цифр підряд
      /\b\d{4}\s?\d{4}\s?\d{4}\s?\d{2}\b/g,  // з пробілами/без пробілів
      /№?\s?(\d{4}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{2})/g,  // з номером та розділювачами
      /накладна[^\d]*(\d{14})/gi,  // після слова "накладна"
      /ТТН[^\d]*(\d{14})/gi,       // після ТТН
      /відправлення[^\d]*(\d{14})/gi // після "відправлення"
    ];
    
    const foundNumbers = new Set();
    
    trackingPatterns.forEach(pattern => {
      const matches = text.match(pattern);
      if (matches) {
        matches.forEach(match => {
          // Видаляємо все крім цифр
          const cleanNumber = match.replace(/\D/g, '');
          if (cleanNumber.length === 14) {
            foundNumbers.add(cleanNumber);
          }
        });
      }
    });
    
    // Видаляємо тимчасові файли
    try {
      await fs.unlink(processedImagePath);
    } catch (error) {
      console.error('Помилка видалення тимчасового файлу:', error);
    }
    
    return Array.from(foundNumbers);
    
  } catch (error) {
    console.error('Помилка OCR розпізнавання:', error);
    throw error;
  }
}

// Функція для завантаження зображення з Viber
async function downloadImageFromViber(imageUrl, filename) {
  try {
    const response = await axios({
      method: 'GET',
      url: imageUrl,
      responseType: 'stream'
    });
    
    const filepath = path.join(uploadsDir, filename);
    const writer = require('fs').createWriteStream(filepath);
    
    response.data.pipe(writer);
    
    return new Promise((resolve, reject) => {
      writer.on('finish', () => resolve(filepath));
      writer.on('error', reject);
    });
  } catch (error) {
    console.error('Помилка завантаження зображення:', error);
    throw error;
  }
}
  try {
    const response = await axios.post(NOVA_POSHTA_API_URL, {
      apiKey: NOVA_POSHTA_API_KEY,
      modelName: "Address",
      calledMethod: "getCities",
      methodProperties: {}
    });

    return response.data.success ? response.data.data : [];
  } catch (error) {
    console.error('Помилка при отриманні списку міст:', error);
    return [];
  }
}

// Обробка подій бота
bot.on(BotEvents.SUBSCRIBED, async (response) => {
  try {
    const user = new User({
      viberUserId: response.userProfile.id,
      name: response.userProfile.name,
      avatar: response.userProfile.avatar,
      language: response.userProfile.language,
      country: response.userProfile.country
    });
    
    await user.save();
    console.log(`Новий користувач підписався: ${response.userProfile.name}`);
    
    bot.sendMessage(response.userProfile, new TextMessage(
      "Вітаю! 👋\n\n" +
      "Я бот для відстеження посилок Нової Пошти.\n\n" +
      "Ви можете:\n" +
      "📝 Надіслати номер накладної (наприклад: 20450123456789)\n" +
      "📷 Надіслати фото чеку з накладною - я автоматично розпізнаю номер\n" +
      "💡 Написати 'допомога' для отримання інструкцій"
    ));
  } catch (error) {
    if (error.code !== 11000) { // Ігноруємо помилку дублювання
      console.error('Помилка при збереженні користувача:', error);
    }
  }
});

bot.on(BotEvents.MESSAGE_RECEIVED, async (message, response) => {
  const trackingNumberRegex = /^\d{14}$/;
  
  // Обробка текстових повідомлень
  if (message instanceof TextMessage) {
    const text = message.text.trim();
    
    if (trackingNumberRegex.test(text)) {
      await processTrackingNumber(text, response);
      
    } else if (text.toLowerCase().includes('допомога') || text === '/help') {
      bot.sendMessage(response.userProfile, new TextMessage(
        "ℹ️ Як користуватися ботом:\n\n" +
        "📝 Способи відстеження:\n" +
        "• Надішліть номер накладної (14 цифр)\n" +
        "• Надішліть фото чеку з накладною\n\n" +
        "📋 Приклад номера: 20450123456789\n\n" +
        "📷 Поради для фото:\n" +
        "• Сфотографуйте чек при хорошому освітленні\n" +
        "• Номер накладної має бути чітко видимий\n" +
        "• Тримайте телефон прямо над чеком\n\n" +
        "📱 Команди:\n" +
        "• 'допомога' - показати цю довідку\n" +
        "• 'мої посилки' - останні відстежені посилки"
      ));
      
    } else if (text.toLowerCase().includes('мої посилки')) {
      await showUserShipments(response);
      
    } else {
      bot.sendMessage(response.userProfile, new TextMessage(
        "Надішліть:\n" +
        "📝 Номер накладної (14 цифр)\n" +
        "📷 Фото чеку з накладною\n\n" +
        "Для довідки напишіть 'допомога'"
      ));
    }
  }
  
  // Обробка фото повідомлень
  else if (message instanceof PictureMessage) {
    try {
      bot.sendMessage(response.userProfile, new TextMessage(
        "📷 Аналізую фото чеку...\n" +
        "🔍 Шукаю номер накладної..."
      ));
      
      // Завантажуємо зображення
      const filename = `receipt_${Date.now()}_${response.userProfile.id}.jpg`;
      const imagePath = await downloadImageFromViber(message.media, filename);
      
      // Витягуємо номери накладних
      const trackingNumbers = await extractTrackingNumberFromImage(imagePath);
      
      // Видаляємо оригінальний файл
      try {
        await fs.unlink(imagePath);
      } catch (error) {
        console.error('Помилка видалення файлу:', error);
      }
      
      if (trackingNumbers.length === 0) {
        bot.sendMessage(response.userProfile, new TextMessage(
          "❌ Не вдалося розпізнати номер накладної на фото.\n\n" +
          "💡 Поради:\n" +
          "• Переконайтеся, що номер чітко видимий\n" +
          "• Покращіть освітлення\n" +
          "• Спробуйте сфотографувати ближче\n" +
          "• Або введіть номер вручну"
        ));
        return;
      }
      
      if (trackingNumbers.length === 1) {
        // Один номер - відразу обробляємо
        bot.sendMessage(response.userProfile, new TextMessage(
          `✅ Знайшов номер накладної: ${trackingNumbers[0]}\n🔍 Отримую інформацію...`
        ));
        await processTrackingNumber(trackingNumbers[0], response);
        
      } else {
        // Кілька номерів - даємо вибрати
        let messageText = `📋 Знайшов кілька номерів накладних:\n\n`;
        trackingNumbers.forEach((number, index) => {
          messageText += `${index + 1}. ${number}\n`;
        });
        messageText += `\nНадішліть номер, який потрібно відстежити`;
        
        bot.sendMessage(response.userProfile, new TextMessage(messageText));
      }
      
    } catch (error) {
      console.error('Помилка обробки зображення:', error);
      bot.sendMessage(response.userProfile, new TextMessage(
        "❌ Помилка при обробці зображення.\n" +
        "Спробуйте надіслати інше фото або введіть номер вручну."
      ));
    }
  }
});

// Функція для обробки номера накладної
async function processTrackingNumber(trackingNumber, response) {
  try {
    const shipmentInfo = await getShipmentInfo(trackingNumber);
    
    if (shipmentInfo) {
      // Збереження в базу даних
      const shipmentData = {
        trackingNumber: trackingNumber,
        senderCity: shipmentInfo.CitySender || 'Не вказано',
        recipientCity: shipmentInfo.CityRecipient || 'Не вказано',
        status: shipmentInfo.Status || 'Невідомо',
        viberUserId: response.userProfile.id,
        senderAddress: shipmentInfo.WarehouseSender || '',
        recipientAddress: shipmentInfo.WarehouseRecipient || '',
        weight: parseFloat(shipmentInfo.DocumentWeight) || 0,
        cost: parseFloat(shipmentInfo.DocumentCost) || 0,
        updatedAt: new Date()
      };
      
      await Shipment.findOneAndUpdate(
        { trackingNumber: trackingNumber },
        shipmentData,
        { upsert: true, new: true }
      );
      
      const responseMessage = 
        `📦 Інформація про відправку:\n\n` +
        `📋 Номер: ${trackingNumber}\n` +
        `📍 Маршрут: ${shipmentInfo.CitySender} → ${shipmentInfo.CityRecipient}\n` +
        `📊 Статус: ${shipmentInfo.Status}\n` +
        `⚖️ Вага: ${shipmentInfo.DocumentWeight || 'Не вказано'} кг\n` +
        `💰 Вартість: ${shipmentInfo.DocumentCost || 'Не вказано'} грн\n` +
        `📅 Дата створення: ${shipmentInfo.DateCreated || 'Не вказано'}\n\n` +
        `Надішліть інший номер або фото для нового відстеження.`;
      
      bot.sendMessage(response.userProfile, new TextMessage(responseMessage));
      
    } else {
      bot.sendMessage(response.userProfile, new TextMessage(
        "❌ Не вдалося знайти інформацію про цю відправку.\n\n" +
        "Перевірте правильність номера накладної та спробуйте ще раз."
      ));
    }
    
  } catch (error) {
    console.error('Помилка при обробці відправки:', error);
    bot.sendMessage(response.userProfile, new TextMessage(
      "❌ Виникла помилка при обробці запиту. Спробуйте пізніше."
    ));
  }
}

// Функція для показу посилок користувача
async function showUserShipments(response) {
  try {
    const userShipments = await Shipment.find({ viberUserId: response.userProfile.id })
      .sort({ updatedAt: -1 })
      .limit(5);
    
    if (userShipments.length > 0) {
      let message = "📦 Ваші останні посилки:\n\n";
      userShipments.forEach((shipment, index) => {
        message += `${index + 1}. ${shipment.trackingNumber}\n`;
        message += `   ${shipment.senderCity} → ${shipment.recipientCity}\n`;
        message += `   Статус: ${shipment.status}\n\n`;
      });
      bot.sendMessage(response.userProfile, new TextMessage(message));
    } else {
      bot.sendMessage(response.userProfile, new TextMessage(
        "У вас поки що немає відстежених посилок.\n" +
        "Надішліть номер накладної або фото чеку для відстеження."
      ));
    }
  } catch (error) {
    console.error('Помилка при отриманні посилок користувача:', error);
    bot.sendMessage(response.userProfile, new TextMessage("❌ Помилка при отриманні ваших посилок."));
  }
}

// REST API для адміністрування
app.get('/api/shipments', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    
    const shipments = await Shipment.find()
      .sort({ updatedAt: -1 })
      .skip(skip)
      .limit(limit);
    
    const total = await Shipment.countDocuments();
    
    res.json({
      shipments,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Endpoint для тестування OCR
app.post('/api/ocr/test', upload.single('receipt'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Файл не надано' });
    }
    
    const trackingNumbers = await extractTrackingNumberFromImage(req.file.path);
    
    // Видаляємо завантажений файл
    try {
      await fs.unlink(req.file.path);
    } catch (error) {
      console.error('Помилка видалення файлу:', error);
    }
    
    res.json({
      success: true,
      trackingNumbers,
      count: trackingNumbers.length
    });
    
  } catch (error) {
    console.error('OCR Error:', error);
    res.status(500).json({ 
      error: 'Помилка при обробці зображення',
      details: error.message 
    });
  }
});

app.get('/api/shipments/:trackingNumber', async (req, res) => {
  try {
    const shipment = await Shipment.findOne({ trackingNumber: req.params.trackingNumber });
    if (!shipment) {
      return res.status(404).json({ error: 'Відправка не знайдена' });
    }
    res.json(shipment);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/users', async (req, res) => {
  try {
    const users = await User.find().sort({ createdAt: -1 });
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Статистика
app.get('/api/stats', async (req, res) => {
  try {
    const totalShipments = await Shipment.countDocuments();
    const totalUsers = await User.countDocuments();
    const todayShipments = await Shipment.countDocuments({
      createdAt: { $gte: new Date(new Date().setHours(0, 0, 0, 0)) }
    });
    
    res.json({
      totalShipments,
      totalUsers,
      todayShipments
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Webhook для Viber
app.use("/viber/webhook", bot.middleware());

// Налаштування webhook
app.get('/set_webhook', (req, res) => {
  bot.setWebhook(process.env.WEBHOOK_URL + '/viber/webhook')
    .then(() => res.send('Webhook встановлено'))
    .catch(err => res.status(500).send(err));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Сервер запущено на порті ${PORT}`);
  console.log(`Встановіть webhook: ${process.env.WEBHOOK_URL}/set_webhook`);
});

module.exports = { app, bot };